import { Questionair } from './survey';
import { createReducer, on } from '@ngrx/store';
import { QuestionairAddedAPISuccess, QuestionairFetchAPISuccess } from './survey.action';

export const initialState: ReadonlyArray<Questionair> = [];

export const surveyReducer = createReducer(
  initialState,
  on(QuestionairFetchAPISuccess, (state, { allQuestionair }) => {
    return allQuestionair;
  }),
  on(QuestionairAddedAPISuccess, (state, { response }) => {
    let newState = [...state];
    newState.unshift(response);
    return newState;
  })
);
