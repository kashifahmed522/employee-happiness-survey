export interface AppState {
  apiStatus: string;
  apiResponseMessage: string;
}
