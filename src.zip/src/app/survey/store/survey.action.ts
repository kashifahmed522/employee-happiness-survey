import { createAction, props } from '@ngrx/store';
import { Questionair } from './survey';

export const invokeQuestionairAPI = createAction(
  '[Questionair API] invoke Questionair Fetch API'
);

export const QuestionairFetchAPISuccess = createAction(
  '[Questionair API] Questionair fetch api success',
  props<{ allQuestionair: any }>()
);

export const QuestionairAddedAPISuccess = createAction(
  '[Saved Questionair API Data] added api response',
  props<{ response: Questionair }>()
);
