// Questionair
export interface Questionair {
  id: number;
  question: string;
}
export interface QuestionairState {
  questionair: Questionair[];
}
