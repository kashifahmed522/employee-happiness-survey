import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuestionairComponent } from './questionair/questionair.component';

const routes: Routes = [{ path: '', component: QuestionairComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SurveyRoutingModule { }
