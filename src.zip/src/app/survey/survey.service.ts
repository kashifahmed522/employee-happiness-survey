import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Questionair } from './store/survey';

@Injectable({
  providedIn: 'root',
})
export class SurveyService {
  constructor(private _httpClient: HttpClient) { }

  get() {
    return this._httpClient.get<Questionair>('http://localhost:3000/questionair');
  }

  create(payload: Questionair) {
    return this._httpClient.post<Questionair>('http://localhost:3000/books/', payload);
  }
}
